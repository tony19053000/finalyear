print(1)
